#ifndef A_INTELLIGENCE_H
#define A_INTELLIGENCE_H

#include "showworld.h"
#include "functions.h"
#include "a_intelligence.h"


BOARD art_int (AGENT **agent_grid, unsigned int key);

#endif