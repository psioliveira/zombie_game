#include <stdio.h>
#include <stdlib.h>

#include "functions.h"
#include "showworld.h"
#include "a_intelligence.h"


BOARD art_int (AGENT **agent_grid, unsigned int key){


return key;

}